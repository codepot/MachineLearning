from django.apps import AppConfig


class DajaxConfig(AppConfig):
    name = 'dajax'
